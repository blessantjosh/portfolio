
import React from 'react';
import { motion } from 'framer-motion';

export default function App() {
  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center flex-col gap-4">
      <motion.h1 initial={{ opacity: 0, y: -50 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }} className="text-4xl font-bold">
        Hi, I'm Joshva D 👋
      </motion.h1>
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="text-xl text-gray-300">
        AI & ML Enthusiast | Developer | Designer
      </motion.p>
    </div>
  );
}
